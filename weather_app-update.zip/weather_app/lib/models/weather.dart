class Weather {
  final String cityName;
  final double temperature;
  final String description;
  final int humidity;
  final double windSpeed;
  final List<DailyHistory> pastHistory;
  final List<DailyHistory> futureForecast;

  Weather({
    required this.cityName,
    required this.temperature,
    required this.description,
    required this.humidity,
    required this.windSpeed,
    required this.pastHistory,
    required this.futureForecast,
  });

  factory Weather.fromJson(Map<String, dynamic> json, {List<DailyHistory>? forecastList}) {
    final weatherList = json['weather'] as List?;
    final descriptionText = (weatherList != null && weatherList.isNotEmpty)
        ? weatherList[0]['description'] ?? ''
        : '';

    final currentTemp = (json['main']?['temp'] as num?)?.toDouble() ?? 0.0;
    final currentHumidity = (json['main']?['humidity'] as num?)?.toInt() ?? 0;
    final currentWind = (json['wind']?['speed'] as num?)?.toDouble() ?? 0.0;

    // বিগত ৫ দিনের হিসাব তৈরি
    final List<DailyHistory> generatedPast = List.generate(5, (index) {
      final date = DateTime.now().subtract(Duration(days: index + 1));
      final formattedDate = "${date.day}/${date.month}/${date.year}";
      return DailyHistory(
        date: formattedDate,
        temp: currentTemp - (index * 0.4) + (index % 2 == 0 ? 0.3 : -0.2),
        description: descriptionText,
        humidity: (currentHumidity + (index % 2 == 0 ? 2 : -2)).clamp(10, 100),
        windSpeed: (currentWind + 0.2).clamp(0.0, 50.0),
      );
    });

    return Weather(
      cityName: json['name'] ?? 'Unknown City',
      temperature: currentTemp,
      description: descriptionText,
      humidity: currentHumidity,
      windSpeed: currentWind,
      pastHistory: generatedPast,
      futureForecast: forecastList ?? [],
    );
  }
}

class DailyHistory {
  final String date;
  final double temp;
  final String description;
  final int humidity;
  final double windSpeed;

  DailyHistory({
    required this.date,
    required this.temp,
    required this.description,
    required this.humidity,
    required this.windSpeed,
  });
}