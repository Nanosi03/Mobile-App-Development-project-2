class ApiConfig {
  // প্রাইভেট কনস্ট্রাক্টর, যাতে দুর্ঘটনাবশত কেউ ApiConfig() কল করতে না পারে
  ApiConfig._();

  static const String baseUrl =
      'https://api.openweathermap.org/data/2.5/weather';

  static const String apiKey = String.fromEnvironment(
    'OPENWEATHER_API_KEY',
    defaultValue: 'e20c07e54afef6e45554c9e1a45bc3ea',
  );

  // ID দিয়ে সার্চ করার URI
  static Uri buildUriByCityId(String cityId) {
    return Uri.parse('$baseUrl?id=$cityId&appid=$apiKey&units=metric');
  }

  // Name দিয়ে সার্চ করার URI
  static Uri buildUriByCityName(String cityName) {
    return Uri.parse('$baseUrl?q=$cityName&appid=$apiKey&units=metric');
  }
}