import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/weather.dart';

class WeatherService {
  final String apiKey;

  WeatherService({this.apiKey = 'e20c07e54afef6e45554c9e1a45bc3ea'});

  Future<Weather> fetchWeatherByCityId(String cityId) async {
    final currentUrl = Uri.parse(
      'https://api.openweathermap.org/data/2.5/weather?id=$cityId&appid=$apiKey&units=metric',
    );
    final forecastUrl = Uri.parse(
      'https://api.openweathermap.org/data/2.5/forecast?id=$cityId&appid=$apiKey&units=metric',
    );
    return _fetchCombinedData(currentUrl, forecastUrl);
  }

  Future<Weather> fetchWeatherByCityName(String cityName) async {
    final currentUrl = Uri.parse(
      'https://api.openweathermap.org/data/2.5/weather?q=$cityName&appid=$apiKey&units=metric',
    );
    final forecastUrl = Uri.parse(
      'https://api.openweathermap.org/data/2.5/forecast?q=$cityName&appid=$apiKey&units=metric',
    );
    return _fetchCombinedData(currentUrl, forecastUrl);
  }

  Future<Weather> fetchWeather(String input) async {
    final trimmedInput = input.trim();
    final isNumeric = RegExp(r'^[0-9]+$').hasMatch(trimmedInput);

    if (isNumeric) {
      return fetchWeatherByCityId(trimmedInput);
    } else {
      return fetchWeatherByCityName(trimmedInput);
    }
  }

  Future<Weather> _fetchCombinedData(Uri currentUrl, Uri forecastUrl) async {
    final currentResponse = await http.get(currentUrl);

    if (currentResponse.statusCode != 200) {
      throw Exception('City not found or invalid input!');
    }

    final currentJson = jsonDecode(currentResponse.body);
    List<DailyHistory> futureForecast = [];

    try {
      final forecastResponse = await http.get(forecastUrl);
      if (forecastResponse.statusCode == 200) {
        final forecastJson = jsonDecode(forecastResponse.body);
        final List list = forecastJson['list'] ?? [];

        for (int i = 0; i < list.length && futureForecast.length < 5; i += 8) {
          final item = list[i];
          final dateTimeStr = item['dt_txt'] ?? '';
          final dateStr = dateTimeStr.split(' ')[0];
          final dateParts = dateStr.split('-');
          final formattedDate = dateParts.length == 3
              ? "${dateParts[2]}/${dateParts[1]}/${dateParts[0]}"
              : dateStr;

          final desc = (item['weather'] != null && item['weather'].isNotEmpty)
              ? item['weather'][0]['description'] ?? ''
              : '';

          futureForecast.add(
            DailyHistory(
              date: formattedDate,
              temp: (item['main']?['temp'] as num?)?.toDouble() ?? 0.0,
              description: desc,
              humidity: (item['main']?['humidity'] as num?)?.toInt() ?? 0,
              windSpeed: (item['wind']?['speed'] as num?)?.toDouble() ?? 0.0,
            ),
          );
        }
      }
    } catch (_) {}

    return Weather.fromJson(currentJson, forecastList: futureForecast);
  }
}